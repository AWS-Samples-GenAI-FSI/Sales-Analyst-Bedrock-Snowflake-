"""
LangGraph workflow components for the GenAI Sales Analyst application.
"""