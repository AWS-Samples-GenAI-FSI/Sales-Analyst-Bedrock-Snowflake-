"""
Amazon Bedrock integration for the GenAI Sales Analyst application.
"""