"""
Utility functions for the GenAI Sales Analyst application.
"""