"""
Monitoring module for the GenAI Sales Analyst application.
"""